These test pcap files are individual packets broken out of a pcap
containing 4 DHCP messages. The original source of the PCAP file is

https://wiki.wireshark.org/SampleCaptures?action=AttachFile&do=get&target=dhcp.pcap
